# وِصلة | Wesla

منصة مصرية أولية للتسويق بالعمولة تربط التجار بالمسوقين والعملاء.

## المكونات
- FastAPI + SQLAlchemy
- PostgreSQL عبر Supabase (قاعدة البيانات الحقيقية ومخططها أُنشئ بالفعل)
- واجهة الموقع: `/`
- لوحة الإدارة المنفصلة: `/control`
- API مشترك: `/api/...`

## التشغيل المحلي للاختبار
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

للاختبار:
```bash
pytest -q
```

## قبل النشر
لا تستخدم SQLite في الإنتاج. اضبط `DATABASE_URL` وبيانات المدير كـ Secrets في الاستضافة، ثم راجع `DEPLOY_AR.md`. لا تشارك كلمات المرور أو مفاتيح قاعدة البيانات.

**حالة المشروع:** مخطط قاعدة بيانات Supabase موجود، واختبار محلي أساسي ناجح. التطبيق نفسه لم يُنشر بعد، ولم يتم إدخال بيانات اتصال قاعدة البيانات السرية في الاستضافة.
