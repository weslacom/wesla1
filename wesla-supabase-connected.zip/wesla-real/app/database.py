import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, DeclarativeBase

raw_url = os.getenv('DATABASE_URL', 'sqlite:///./wesla.db').strip()
# SQLAlchemy 2 uses the psycopg v3 driver explicitly; normalize provider URLs.
if raw_url.startswith('postgres://'):
    raw_url = 'postgresql+psycopg://' + raw_url[len('postgres://'):]
elif raw_url.startswith('postgresql://'):
    raw_url = 'postgresql+psycopg://' + raw_url[len('postgresql://'):]
if raw_url.startswith('postgresql+psycopg://') and 'sslmode=' not in raw_url:
    raw_url += ('&' if '?' in raw_url else '?') + 'sslmode=require'
if os.getenv('ENVIRONMENT', 'development').lower() == 'production' and raw_url.startswith('sqlite'):
    raise RuntimeError('Production requires PostgreSQL. Set DATABASE_URL to your hosted PostgreSQL connection string.')

connect_args = {'check_same_thread': False} if raw_url.startswith('sqlite') else {}
engine = create_engine(raw_url, connect_args=connect_args, pool_pre_ping=True, pool_recycle=300)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)

class Base(DeclarativeBase):
    pass

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
